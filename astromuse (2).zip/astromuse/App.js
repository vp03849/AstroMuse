import * as React from 'react';
import { StatusBar } from 'expo-status-bar';
import { ImageBackground, StyleSheet, Text, View } from 'react-native';
import { RFValue } from "react-native-responsive-fontsize";
import { TouchableOpacity, Button } from 'react-native';


export default function App() {
  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('./assets/b.jpg')}
        resizeMode="cover"
        style={styles.cosmos}>
        <Text style={styles.welcomeText}>Welcome to AstroMuse!</Text>
        <TouchableOpacity style = {{alignContent: 'center', alignItems: 'center', padding: 20, borderRadius: 50, backgroundColor: 'white', marginBottom: 200, }} onPress = {{}}>
        <Text style = {{color: 'black', fontFamily: 'JetBrains Mono', fontSize: 14}}>
        Description
        </Text>
        </TouchableOpacity>
        <TouchableOpacity style = {{alignContent: 'center', alignItems: 'center', padding: 20, borderRadius: 50, backgroundColor: 'white', marginBottom: 550, }} onPress = {{}}>
        <Text style = {{color: 'black', fontFamily: 'JetBrains Mono', fontSize: 14}}>
        B Tauri
        </Text>
        </TouchableOpacity>
         <TouchableOpacity style = {{alignContent: 'center', alignItems: 'center', padding: 20, borderRadius: 50, backgroundColor: 'white', marginBottom: 650, }}>
        <Text style = {{color: 'black', fontFamily: 'JetBrains Mono', fontSize: 14}}>
        Aldebaran
        </Text>
        </TouchableOpacity>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cosmos: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    resizeMode: 'cover',
    width: 333,
  },
  welcomeText: {
    color: 'white',
    fontFamily: 'JetBrains Mono',
    fontStyle: 'Bold',
    fontSize: 25,
    position: 'absolute',
    top: 15,
  },
});
